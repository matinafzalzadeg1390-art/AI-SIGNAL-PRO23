# AI SIGNAL 0.2.0 — Binance live market

Native Android app using Kotlin + Jetpack Compose.

## What's real in this version
- Calls Binance public Spot REST API.
- Reads active `TRADING` spot symbols quoted in USDT from `/api/v3/exchangeInfo`.
- Reads 24-hour ticker data from `/api/v3/ticker/24hr`.
- Filters to active USDT spot pairs and sorts by quote volume.
- Search, manual refresh, current price, 24-hour change and quote volume.
- No Binance API key is required for these public market-data endpoints.

## Build with GitHub Actions
1. Upload all files to a GitHub repository (keep `.github/workflows/build.yml`).
2. Push to `main` or `master`.
3. Open Actions → Build AI SIGNAL APK.
4. Download the `AI-SIGNAL-debug-apk` artifact from a successful run.

## Important
- "All" means all active Binance Spot pairs quoted in USDT, not every quote currency or derivatives market.
- Binance availability may vary by region/network. If Binance blocks access, the app will show the HTTP error.
- Data is public market data, not a recommendation to trade.
- This version does not yet generate signals and does not connect OpenRouter.
- Do not put OpenRouter secrets in the APK or public repository. A secure backend is required for the next stage.
- Start with paper-trading evaluation; no profit or accuracy is guaranteed.

## App icon
A custom AI SIGNAL launcher icon is included in all Android density folders and adaptive-icon resources.
GitHub Actions packages it automatically into the APK; no manual icon step is needed.
