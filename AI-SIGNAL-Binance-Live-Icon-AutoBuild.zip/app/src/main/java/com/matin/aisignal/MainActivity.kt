package com.matin.aisignal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.text.DecimalFormat

private val Bg = Color(0xFF0B1110)
private val Panel = Color(0xFF141D1A)
private val Green = Color(0xFF42D392)
private val Red = Color(0xFFFF6B75)
private val Muted = Color(0xFF91A39A)

data class MarketCoin(
    val symbol: String,
    val lastPrice: Double,
    val changePercent: Double,
    val quoteVolume: Double
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SignalApp() }
    }
}

@Composable
fun SignalApp() {
    var tab by remember { mutableIntStateOf(0) }
    var coins by remember { mutableStateOf<List<MarketCoin>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var lastUpdated by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    fun refreshMarket() {
        scope.launch {
            loading = true
            error = null
            try {
                val result = withContext(Dispatchers.IO) { BinanceApi.fetchAllUsdtSpot() }
                coins = result
                lastUpdated = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
                    .format(java.util.Date())
            } catch (e: Exception) {
                error = e.message ?: "دریافت اطلاعات از بایننس ناموفق بود"
            } finally {
                loading = false
            }
        }
    }

    LaunchedEffect(Unit) { refreshMarket() }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Green,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    val labels = listOf("خانه", "بازار", "سیگنال‌ها", "درباره")
                    val icons = listOf(Icons.Default.Home, Icons.Default.CandlestickChart,
                        Icons.Default.Timeline, Icons.Default.Info)
                    labels.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = tab == index, onClick = { tab = index },
                            icon = { Icon(icons[index], contentDescription = label) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { padding ->
            when (tab) {
                1 -> MarketScreen(
                    modifier = Modifier.padding(padding), coins = coins, loading = loading,
                    error = error, lastUpdated = lastUpdated, query = query,
                    onQuery = { query = it }, onRefresh = { refreshMarket() }
                )
                else -> LazyColumn(
                    modifier = Modifier.fillMaxSize().background(Bg).padding(padding),
                    contentPadding = PaddingValues(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text("AI SIGNAL", color = Green, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(when(tab) { 2 -> "مرکز سیگنال‌ها"; 3 -> "درباره برنامه"; else -> "داشبورد بازار" },
                                    color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                            }
                            Surface(color = Panel, shape = RoundedCornerShape(14.dp)) {
                                Icon(Icons.Default.AutoGraph, null, tint = Green,
                                    modifier = Modifier.padding(12.dp).size(24.dp))
                            }
                        }
                    }
                    when (tab) {
                        0 -> {
                            item {
                                Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text("اتصال بازار", color = Muted, fontSize = 13.sp)
                                        Text(if (coins.isNotEmpty()) "متصل به Binance" else "در حال بررسی اتصال",
                                            color = if (coins.isNotEmpty()) Green else Color.White,
                                            fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                        Text(if (coins.isNotEmpty()) "${coins.size} جفت‌ارز USDT دریافت شد"
                                            else "برای مشاهده قیمت‌های زنده وارد بخش بازار شو.",
                                            color = Muted, fontSize = 13.sp)
                                    }
                                }
                            }
                            item {
                                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    MetricCard("جفت‌ارزهای دریافت‌شده", if (coins.isEmpty()) "—" else coins.size.toString(),
                                        Modifier.weight(1f))
                                    MetricCard("سیگنال معتبر", "۰", Modifier.weight(1f))
                                }
                            }
                            item {
                                Button(onClick = { tab = 1 }, modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Bg)) {
                                    Icon(Icons.Default.CandlestickChart, null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("مشاهده بازار زنده")
                                }
                            }
                        }
                        2 -> item { EmptyPanel("هنوز سیگنالی ثبت نشده",
                            "پس از تکمیل موتور تحلیل و ارزیابی آزمایشی، نتایج اینجا نمایش داده می‌شوند.") }
                        else -> item { EmptyPanel("AI SIGNAL نسخه ۰.۲",
                            "داده بازار از Binance دریافت می‌شود.\nساخته‌شده توسط متین افضل‌زاده\nابزار تحلیل آموزشی؛ بدون تضمین سود یا صحت سیگنال.") }
                    }
                }
            }
        }
    }
}

@Composable
private fun MarketScreen(
    modifier: Modifier, coins: List<MarketCoin>, loading: Boolean, error: String?,
    lastUpdated: String?, query: String, onQuery: (String) -> Unit, onRefresh: () -> Unit
) {
    val filtered = remember(coins, query) {
        coins.filter { it.symbol.contains(query.trim().uppercase()) }
    }
    Column(modifier.fillMaxSize().background(Bg).padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("بازار زنده", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("Binance Spot · USDT", color = Muted, fontSize = 12.sp)
            }
            IconButton(onClick = onRefresh, enabled = !loading) {
                if (loading) CircularProgressIndicator(modifier = Modifier.size(22.dp), color = Green, strokeWidth = 2.dp)
                else Icon(Icons.Default.Refresh, "تازه‌سازی", tint = Green)
            }
        }
        OutlinedTextField(
            value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("جستجوی نماد؛ مثل BTCUSDT") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            singleLine = true, shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Green, unfocusedBorderColor = Panel,
                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                cursorColor = Green
            )
        )
        Spacer(Modifier.height(8.dp))
        Text(
            when {
                loading -> "در حال دریافت فهرست و قیمت‌ها..."
                error != null -> "خطا در دریافت اطلاعات"
                else -> "${filtered.size} از ${coins.size} جفت‌ارز · آخرین بروزرسانی: ${lastUpdated ?: "—"}"
            }, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 6.dp)
        )
        if (error != null) {
            Surface(color = Panel, shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(error, color = Red, fontSize = 13.sp)
                    Text("ممکن است دسترسی شبکه یا محدودیت منطقه‌ای بایننس مانع اتصال شده باشد.",
                        color = Muted, fontSize = 12.sp)
                    TextButton(onClick = onRefresh) { Text("تلاش دوباره") }
                }
            }
        } else if (loading && coins.isEmpty()) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Green)
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween) {
                Text("دارایی", color = Muted, fontSize = 11.sp)
                Text("قیمت / تغییر ۲۴ساعته", color = Muted, fontSize = 11.sp)
            }
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(7.dp),
                contentPadding = PaddingValues(bottom = 18.dp)
            ) {
                items(filtered, key = { it.symbol }) { coin -> CoinRow(coin) }
            }
        }
    }
}

@Composable
private fun CoinRow(coin: MarketCoin) {
    val positive = coin.changePercent >= 0
    Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 13.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(coin.symbol.removeSuffix("USDT"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("USDT · حجم ${compact(coin.quoteVolume)}", color = Muted, fontSize = 10.sp)
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(priceFormat(coin.lastPrice), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text("${if (positive) "+" else ""}${"%.2f".format(java.util.Locale.US, coin.changePercent)}%",
                    color = if (positive) Green else Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

private object BinanceApi {
    private const val BASE = "https://api.binance.com"

    fun fetchAllUsdtSpot(): List<MarketCoin> {
        val exchange = getJson("$BASE/api/v3/exchangeInfo")
        val activeUsdt = mutableSetOf<String>()
        val symbols = exchange.getJSONArray("symbols")
        for (i in 0 until symbols.length()) {
            val item = symbols.getJSONObject(i)
            if (item.optString("status") == "TRADING" &&
                item.optString("quoteAsset") == "USDT" &&
                item.optBoolean("isSpotTradingAllowed", false)) {
                activeUsdt.add(item.optString("symbol"))
            }
        }

        val tickers = getJsonArray("$BASE/api/v3/ticker/24hr")
        val result = ArrayList<MarketCoin>()
        for (i in 0 until tickers.length()) {
            val item = tickers.getJSONObject(i)
            val symbol = item.optString("symbol")
            if (symbol in activeUsdt) {
                result.add(
                    MarketCoin(
                        symbol = symbol,
                        lastPrice = item.optString("lastPrice").toDoubleOrNull() ?: 0.0,
                        changePercent = item.optString("priceChangePercent").toDoubleOrNull() ?: 0.0,
                        quoteVolume = item.optString("quoteVolume").toDoubleOrNull() ?: 0.0
                    )
                )
            }
        }
        return result.sortedByDescending { it.quoteVolume }
    }

    private fun getJson(url: String): org.json.JSONObject =
        org.json.JSONObject(request(url))

    private fun getJsonArray(url: String): JSONArray = JSONArray(request(url))

    private fun request(urlString: String): String {
        val connection = (URL(urlString).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 20000
            setRequestProperty("Accept", "application/json")
        }
        try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) {
                throw IllegalStateException("Binance HTTP $code: ${body.take(180)}")
            }
            return body
        } finally {
            connection.disconnect()
        }
    }
}

private fun priceFormat(value: Double): String {
    return when {
        value >= 1000 -> DecimalFormat("#,##0.00").format(value)
        value >= 1 -> DecimalFormat("#,##0.0000").format(value)
        else -> DecimalFormat("0.########").format(value)
    }
}
private fun compact(value: Double): String = when {
    value >= 1_000_000_000 -> "%.1fB".format(java.util.Locale.US, value / 1_000_000_000)
    value >= 1_000_000 -> "%.1fM".format(java.util.Locale.US, value / 1_000_000)
    value >= 1_000 -> "%.1fK".format(java.util.Locale.US, value / 1_000)
    else -> "%.0f".format(java.util.Locale.US, value)
}

@Composable
private fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = modifier) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, color = Muted, fontSize = 12.sp)
            Text(value, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        }
    }
}
@Composable
private fun EmptyPanel(title: String, detail: String) {
    Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(detail, color = Muted, fontSize = 14.sp, lineHeight = 22.sp)
        }
    }
}
